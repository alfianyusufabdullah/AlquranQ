package com.alfianyusufabdullah.alquranq.presentation.listsurah;

import com.alfianyusufabdullah.alquranq.base.BaseView;
import com.alfianyusufabdullah.alquranq.model.Surah;

/**
 * Created by jonesrandom on 2/22/18.
 *
 * @site www.androidexample.web.id
 * @github @alfianyusufabdullah
 */

interface ListSurahView extends BaseView<Surah> {
}
