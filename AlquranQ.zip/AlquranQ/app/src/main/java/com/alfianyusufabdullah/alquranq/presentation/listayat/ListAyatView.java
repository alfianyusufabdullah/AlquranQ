package com.alfianyusufabdullah.alquranq.presentation.listayat;

import com.alfianyusufabdullah.alquranq.base.BaseView;
import com.alfianyusufabdullah.alquranq.model.Ayat;

/**
 * Created by jonesrandom on 2/22/18.
 *
 * @site www.androidexample.web.id
 * @github @alfianyusufabdullah
 */

interface ListAyatView extends BaseView<Ayat> {
}
