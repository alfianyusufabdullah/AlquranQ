# AlquranQ
Terjemahan Alquran bahasa Indonesia &amp; Bahasa Inggris

<img src="https://github.com/alfianyusufabdullah/AlquranQ/raw/master/app/ss1.png" width="250"> <img src="https://github.com/alfianyusufabdullah/AlquranQ/raw/master/app/ss2.png" width="250"> <img src="https://github.com/alfianyusufabdullah/AlquranQ/raw/master/app/ss3.png" width="250">
